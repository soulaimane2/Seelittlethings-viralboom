<div class="footer">
	<div class="footer-overlay">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<?php dynamic_sidebar("Tagsmenu");?>
				</div>
				<div class="col-md-4">
					<!--h2> Contact Us </h2-->
					
					<!--h2 style="padding-bottom: 10px; ">
						<i class="fa fa-line-chart" aria-hidden="true"></i>
	 					ViralBoom
	 				</h2-->
					<?php dynamic_sidebar("Aboutmenu");?>
				</div>
				<div class="social col-md-4">
					<h2> Find Us </h2>
					<ul style="list-style: none;">
						<li style="margin-top: 9px;" class="fb">
			<a href="https://www.facebook.com/SeeLittleTings/" style="color:#f9f9f9"><i class="fa fa-facebook" aria-hidden="true"></i></a>
		</li>
		<li style="margin-top: 9px;" class="ins">
			<a href="https://www.instagram.com/seethings3719/" style="color:#f9f9f9"><i class="fa fa-instagram" aria-hidden="true"></i></a>
		</li>
		<li style="margin-top: 9px;" class="tw">
			<a href="https://twitter.com/seelittle3/" style="color:#f9f9f9"><i class="fa fa-twitter" aria-hidden="true"></i></a>
		</li>
		<li style="margin-top: 9px;" class="gp">
			<a href="https://www.youtube.com/channel/UCg2Q-PDzkW9T9xuN4emZWCQ" style="color:#f9f9f9"><i class="fa fa-youtube" aria-hidden="true"></i></a>
		</li>
		<li style="margin-top: 9px;" class="pin">
			<a href="https://www.pinterest.com/Seelittlethings1/" style="color:#f9f9f9"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
		</li>
		<!--li style="margin-top: 9px;" class="lin">
			<a href="#" style="color:#f9f9f9"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
		</li-->
		<li style="margin-top: 9px;" class="redd">
			<a href="https://www.reddit.com/user/seelittlethings12/" style="color:#f9f9f9"><i class="fa fa-reddit-alien" aria-hidden="true"></i></a>
		</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<?php footermenu() ?>
<div class="copyright">
	All Copyright Reserved &copy; 2019
</div>