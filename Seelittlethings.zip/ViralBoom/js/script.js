jQuery(document).ready(function( $ ) {
	
	$(window).load(function() {
		// Animate loader off screen
		$(".overeverything").fadeOut("slow");;
	});
	
});