<?php get_header()?>
<div class="container">
	
	<h1 style="text-align: center;padding: 50px"> PAGE NOT FOUND 404 </h1>

</div>

<?php require_once("inc/prefooter.php")?>
<?php get_footer()?>